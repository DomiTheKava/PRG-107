import UIKit

// variable defintions
let value1 = 3
let value2 = 2

// operators
// Add/Subtract/Multiply/Divide/Percentages

func add(val1: Int, val2: Int) -> Int { return val1 + val2}
func subtract(val1: Int, val2: Int) -> Int { return val1 - val2}
func multiply(val1: Int, val2: Int) -> Int { return val1 * val2}
func divide(val1: Int, val2: Int) -> Int { return val1 / val2}

// Output

var output = multiply(val1: value1, val2: value2)
print(output)

